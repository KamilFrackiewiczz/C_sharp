﻿using System;

namespace WarsztatSamochodowy
{
    //klasa ze statycznymi metodami liczacymi
    class Quantity
    {   
        public static int redQnt = 0, blQnt = 0, grnQnt = 0, unkQnt=0;
    //Metoda liczaca sume podanych argumentow int
        public static int get(params int[] args)
        {
            int sum=0;
                for (int i = 0; i < args.Length; i++)
            {
                sum = sum + args[i];
            }
            return sum;
        }
     //Metoda zwracaja sume wszystkich pojazdow
        public static int getAllVehs()
        {
            return redQnt + blQnt + grnQnt + unkQnt;
        }
        //Metoda zwracajaca ceny pojazdów
        public static int getPriceRed()
        {
            return Random(10000,15000);
        }
        public static int getPriceBlue()
        {
            return Random(5000,10000);
        }
        public static int getPriceGreen()
        {
            return Random(1000,5000);
        }
        //Metoda zwracajaca losowa liczbe
        public static int Random(int min, int max)
        {
            Random random = new Random();
            return random.Next(min,max);
        }
        //Funkcje listujące
        public static void listAll()
        {
            for (int i=1; i<Vehicles.nextId; i++)
            {
                Console.WriteLine(Vehicles.table[i].id + " / " + Vehicles.table[i].name + " / " + Vehicles.table[i].colour + " / " + Vehicles.getEnginePowerById(i) + "HP " + Vehicles.getEngineStateById(i) + " engine / "+Vehicles.table[i].type+" / "+Vehicles.getOwner(i));
            }
        }
        public static void listAllCars()
        {
                for (int i = 1; i < Vehicles.nextId; i++)
                {
                    if (Vehicles.table[i].type=="car")
                        Console.WriteLine(Vehicles.table[i].id + " / " + Vehicles.table[i].name + " / " + Vehicles.table[i].colour + " / " + Vehicles.getEnginePowerById(i) + "HP " + Vehicles.getEngineStateById(i) + " engine / " + Vehicles.table[i].type + " / " + Vehicles.getOwner(i));
                }
        }
        public static void listAllMotors()
        {
            for (int i = 1; i < Vehicles.nextId; i++)
            {
                if (Vehicles.table[i].type == "motor")
                    Console.WriteLine(Vehicles.table[i].id + " / " + Vehicles.table[i].name + " / " + Vehicles.table[i].colour + " / " + Vehicles.getEnginePowerById(i) + "HP " + Vehicles.getEngineStateById(i) + " engine / " + Vehicles.table[i].type + " / " + Vehicles.getOwner(i));
            }
        }
    }
        
}
