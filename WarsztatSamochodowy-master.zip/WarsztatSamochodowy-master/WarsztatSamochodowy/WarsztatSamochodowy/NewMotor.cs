﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace WarsztatSamochodowy
{
    class NewMotor : NewCar
    {
        new public static void add(string name, string colour, int EnginePower, string EngineState = "new", string OwnerName="", string OwnerLastName="")
        {
            if (name == "" && colour == "")
            {
                Console.WriteLine("Dodany motor do bazy nie posiada Nazwy,koloru ani ceny!");
            }
            else if (name != "" && colour == "")
            {
                Console.WriteLine("Dodany motor do bazy nie posiada koloru ani ceny");
            }
            else if (name == "" && colour != "")
            {
                Console.WriteLine("Dodany motor do bazy nie posiada marki");
            }
            else Console.WriteLine("");

            string type = "motor";

            string temp_name;
            if (name != "") temp_name = name; else temp_name = "Niezidentyfikowana marka";
            string temp_colour;
            if (colour != "") temp_colour = colour; else temp_colour = "unk";

            string tempEngineState;
            if (EngineState != "") tempEngineState = EngineState; else tempEngineState = "Old";

            string tempOwnerName = OwnerName;
            String tempOwnerLastName = OwnerLastName;


            if (tempOwnerName == "" || tempOwnerLastName == "") tempOwnerName = "Brak wlasciciela";

            Vehicles.table.Add(new Vehicles(temp_name, temp_colour, EnginePower, tempEngineState, tempOwnerName, tempOwnerLastName, type));
            
            //Jezeli podamy wlasciciela pojazdu innego niz defaultowy to funcja doda go do bazy danych klientow i przypisze mu numer ID samochodu z bazy vehicles.table

            if (OwnerName != "" && OwnerLastName != "")
            {
                
                Client.client_table.Add(new Client(OwnerName, OwnerLastName));
                int Q = Client.client_table.Count;
                Client.client_table[Q-1].id_samochodu = Vehicles.nextId-1;
                
            }

        }
    }

    
  
}
