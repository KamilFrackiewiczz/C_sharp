﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Dynamic;
using System.Reflection.Metadata.Ecma335;
using System.Text;



namespace WarsztatSamochodowy
{
    class Client : Human
    {
        public static Collection<Client> client_table = new Collection<Client>();
        public int client_id;
        public static int next_client_id = 0;
        public int? id_samochodu=null;

        public Client(string firstname, string lastname) : base(firstname, lastname)
        {

            this.type = "client";
            this.client_id = next_client_id;
            next_client_id++;
            
        }

        
        
        
        //Klasy override

            //Funkcja AddToTable dziedziczona z abstracykjnej metody w klasie Human
        public override void AddToTable(string firstname, string lastname,string nothing = "null")
        {
            client_table.Add(new Client(firstname, lastname));
            
        }
        public string returnifId()
        {
            if (id_samochodu != null) return "| Przypisany pojazd o id:";
            else return null;
        }
            //ToString
        public override string ToString()
        {
            return firstname + " " + lastname + " " +returnifId() + id_samochodu; 
        }
    }
}
