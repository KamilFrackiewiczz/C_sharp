﻿using System;

namespace WarsztatSamochodowy
{
    class Time
    {
        public static string Message { get; private set; }

        
        static Time()
        {
            if (DateTime.Now.Hour < 18 && DateTime.Now.Hour > 4)
                Message = "Dzien dobry!";
            else
                Message = "Dobry wieczór!";
            Console.WriteLine("Godzina "+DateTime.Now.Hour+":"+DateTime.Now.Minute);
        }

        public void getHour()
        {
            Console.WriteLine("Jest godzina " + DateTime.Now.Hour);
        }
    }
}
