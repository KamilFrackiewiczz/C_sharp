﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using System.Collections.ObjectModel;

namespace WarsztatSamochodowy
{
    abstract class Human
    {
        public string firstname { get; set; }
        public string lastname { get; set; }      
        public string type { get; protected set; }

        public Human(string firstname = "unk", string lastname = "unk")
        {
            this.firstname = firstname;
            this.lastname = lastname;

        }

        //Klasa abstrakcyjna ktora musi isntiec w kazdej klasie ktora dziedziczy po tej klasie
        abstract public void AddToTable(string firstname, string lastname,string role);
        



    }
}
