﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Dynamic;
using System.Text;

namespace WarsztatSamochodowy
{
    class Worker : Human
    {
        public int worker_id;
        public static int next_worker_id { private set; get; } = 0;
        public string role {  set; get; }
        public static Collection<Worker> worker_table = new Collection<Worker>();
        //public int id_samochodu;


        public Worker(string firstname, string lastname, string role) : base(firstname, lastname)
        {
            this.role = role;
            this.type = "worker";
            this.worker_id = next_worker_id;
            next_worker_id++;

        }
        //Klasy override
        public override void AddToTable(string firstname, string lastname, string role)
        {
            worker_table.Add(new Worker(firstname, lastname, role));
        }
            //ToString
        public override string ToString()
        {
            return firstname + " " + lastname + " - " + role; 
        }
    }
}
