﻿using Microsoft.VisualBasic;
using Microsoft.Win32.SafeHandles;
using System;
using System.Data;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

//Abstrakcyjna funkcja human/abstrakcyjne funkcje Human/worker/client

namespace WarsztatSamochodowy
{
   

    class Warsztat
    {


        static void Main(string[] args)
        {
            //Logowanie
            bool is_correct = false;
            while (is_correct == false)
            {
                string username;
                string password = "";

                Console.Write("Username: ");
                username = Console.ReadLine();

                Console.Write("Password: ");
                do
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    if (key.Key != ConsoleKey.Enter)
                    {
                        password += key.KeyChar;
                        Console.Write("*");
                    }
                    else if (key.Key == ConsoleKey.Enter)
                    {
                        Console.WriteLine();
                        break;
                    }
                } while (true);

                if (username == "admin" && password == "admin")
                {
                    Console.Clear();
                    is_correct = true;
                    Console.WriteLine("Podano poprawne hasło");


                }
                else Console.WriteLine("Nie znaleziono uzytkownika");


            }

            const String nameDev = "Car_Production_SA";

            //Defaultowi Klienci
            Client.client_table.Add(new Client("Kamil", "Frackiewicz"));
            Client.client_table.Add(new Client("Michal", "Nowak"));
            Client.client_table.Add(new Client("Jan", "Kowalski"));
            //Defaultowi pracownicy
            Worker.worker_table.Add(new Worker("Kamil", "Frackiewicz", "Prezes"));
            Worker.worker_table.Add(new Worker("Kacper", "Nowak", "Kasjer"));
            Worker.worker_table.Add(new Worker("Robert", "Kowalski", "Mechanik"));
            //Defaultowe Samochody
            NewCar.add("Volkswagen", "red", 200, "new", "Michal", "Pol");
            NewCar.add("BMW", "blue", 150, "new", "Aneta", "Burak");
            NewCar.add("Toyota", "green", 250, "old", "Józef", "Nowak");
            //Defaultowe motory
            NewMotor.add("Suzuki", "red", 150, "old", "Sebastian", "Mazurek");
            NewMotor.add("Nagasaki", "green", 170, "new", "Lukasz", "Szulc");
            NewMotor.add("Honda", "blue", 250, "old", "Piotr", "Olbracht");


            Console.Clear();
            Console.WriteLine("Podano poprawne hasło");
            Console.WriteLine(Time.Message);
            Console.WriteLine("Witamy w panelu obsługi warsztatu " + nameDev + "! :)");
            
            int menu_option = 0;
            int menu_state = 0;

            while (menu_state == 0)
            {
                switch (menu_option)
                {
                    case 0:
                       
                        Console.WriteLine("Co chcesz zrobic?");
                        Console.WriteLine("[1] Pracownicy [2] Klienci [3] Pojazdy [4] Dodaj nowy [5] Wyjdz");
            
                        try
                        {
                            menu_option = Convert.ToInt32(Console.ReadLine());
                        }
                        catch(System.FormatException)
                        {
                            Console.Clear();
                            goto case 0;
                        }

                        if (menu_option == 1) goto case 1;
                        if (menu_option == 2) goto case 2;
                        if (menu_option == 3) goto case 3;
                        if (menu_option == 4) goto case 4;
                        if (menu_option == 5)
                        {
                            Console.Clear();
                            Console.WriteLine("Do widzenia! :)");
                            menu_state = 1;
                            break;
                        }

                        break;

                    case 1:

                        int menu_worker_option = 0;

                        switch (menu_worker_option)
                        {
                            case 0:

                                Console.Clear();
                                Console.WriteLine("Zakładka pracownicy. Co chcesz zrobić?");
                                Console.WriteLine("[1] Dodaj nowego pracownika [2] Wypisz pracowników [3] Usun pracownika [4] Przypisz pracownikowi nowa role [5] Cofnij");

                                try
                                {
                                    menu_worker_option = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (System.FormatException)
                                {
                                    goto case 0;
                                }

                                if (menu_worker_option == 1) goto case 1;
                                if (menu_worker_option == 2) goto case 2;
                                if (menu_worker_option == 3) goto case 3;
                                if (menu_worker_option == 4) goto case 4;
                                if (menu_worker_option == 5) goto case 5;

                                break;

                            case 1:

                                Console.Clear();

                                string tempfirstname;
                                string templastname;
                                string temprole;

                                Console.Write("Imie:");
                                tempfirstname = Console.ReadLine();

                                if (tempfirstname == "")
                                {
                                    tempfirstname = "Brak Imienia i Nazwiska";
                                    templastname = "";
                                }
                                else
                                {
                                    Console.Write("Nazwisko:");
                                    templastname = Console.ReadLine();
                                }

                                Console.Write("Rola:");
                                temprole = Console.ReadLine();

                                Worker.worker_table.Add(new Worker(tempfirstname, templastname, temprole));

                                Console.Clear();
                                Console.WriteLine("Dodano nowego pracownika!");
                                Console.WriteLine("Enter aby kontynuować...");
                                Console.Read();

                                goto case 0;

                            case 2:

                                Console.Clear();

                                for (int i = 0; i < Worker.worker_table.Count; i++)
                                {
                                    Console.Write("ID:"+i+"|");
                                    Console.WriteLine(Worker.worker_table[i]);
                                }
                                Console.WriteLine("Enter aby kontynuować...");
                                Console.ReadLine();

                                goto case 0;

                            case 3:

                                Console.Clear();
                                Console.Write("Wpisz numer ID pracownika ktorego chcesz usunac:");
                                try
                                {
                                    int id_case3 = Convert.ToInt32(Console.ReadLine());
                                    try
                                    {
                                        Worker.worker_table.RemoveAt(id_case3);
                                        Console.WriteLine("Usunieto pracownika");
                                    }
                                    catch (System.ArgumentOutOfRangeException)
                                    {
                                        Console.WriteLine("Nie ma takiego ID");
                                    }
                                }
                               catch (System.FormatException)
                                {
                                    Console.WriteLine("Wcisnales enter");
                                    Console.ReadLine();
                                    goto case 3;
                                }
                                Console.WriteLine("Enter aby kontynuować...");
                                Console.ReadLine();
                                break;

                            case 4:

                                Console.Clear();
                                Console.Write("Wpisz numer ID pracownika któremu chcesz zmienić role:");
                                
                                try
                                {
                                    int id_case4 = Convert.ToInt32(Console.ReadLine());
                                    try
                                    {
                                        Console.Write("Nowa rola:");
                                        Worker.worker_table[id_case4].role = Console.ReadLine();
                                        Console.WriteLine("Zmieniono role");
                                    }
                                    catch(System.ArgumentOutOfRangeException)
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Nie ma takiego ID");
                                        Console.WriteLine("Enter aby kontynuować...");
                                        Console.ReadLine();
                                        goto case 0;
                                    }
                                }
                                catch(System.FormatException)
                                {
                                    goto case 4;
                                }
                                Console.WriteLine("Enter aby kontynuować...");
                                Console.ReadLine();
                                Console.Clear();
                                break;

                            case 5:
                                Console.Clear();
                                menu_option = 0;
                                break;


                        }
                        break;
                    case 2:

                        int menu_client_option = 0;

                        switch (menu_client_option)
                        {
                            case 0:

                                Console.Clear();
                                Console.WriteLine("Zakładka Klienci. Co chcesz zrobić?");
                                Console.WriteLine("[1] Dodaj nowego klienta [2] Wypisz klientow [3] Usun klienta [4] Przypisz Klientowi istniejacy samochod  [5] Cofnij");

                                try
                                {
                                    menu_client_option = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (System.FormatException)
                                {
                                    Console.Clear();
                                    goto case 0;
                                }

                                if (menu_client_option == 1) goto case 1;
                                if (menu_client_option == 2) goto case 2;
                                if (menu_client_option == 3) goto case 3;
                                if (menu_client_option == 4) goto case 4;
                                if (menu_client_option == 5) goto case 5;


                                break;

                            case 1:

                                Console.Clear();

                                string tempfirstname;
                                string templastname;

                                Console.Write("Imie:");
                                tempfirstname = Console.ReadLine();

                                if (tempfirstname == "")
                                {
                                    tempfirstname = "Brak Imienia i Nazwiska";
                                    templastname = "";
                                }
                                else
                                {
                                    Console.Write("Nazwisko:");
                                    templastname = Console.ReadLine();
                                }

                                Client.client_table.Add(new Client(tempfirstname, templastname));

                                Console.Clear();
                                Console.WriteLine("Dodano nowego Klienta!");

                                goto case 0;

                            case 2:

                                Console.Clear();

                                for (int i = 0; i < Client.client_table.Count; i++)
                                {
                                    Console.Write("ID:"+i + "|");
                                    Console.WriteLine(Client.client_table[i]);
                                }
                                Console.WriteLine("Wypisywanie zakonczone...");
                                Console.WriteLine("enter aby kontynuowac...");
                                Console.Read();
                                Console.WriteLine();

                                break;

                            case 3:

                                Console.Clear();

                                Console.Write("Wpisz numer ID klienta ktorego chcesz usunac:");
                                
                                try
                                {
                                    int id_case3 = Convert.ToInt32(Console.ReadLine());
                                    try
                                    {
                                        Client.client_table.RemoveAt(id_case3);
                                    }
                                    catch (System.ArgumentOutOfRangeException)
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Nie ma takiego klienta");
                                        Console.WriteLine("enter aby kontynuowac...");
                                        Console.Read();
                                        goto case 0;
                                    }
                                }
                                catch(System.FormatException)
                                {
                                    goto case 3;
                                }
                                
                                Console.WriteLine("Usunieto klienta");
                                Console.WriteLine("enter aby kontynuowac...");
                                Console.Read();
                                goto case 0;

                            case 4:

                                Console.Clear();

                                Console.Write("Wpisz numer ID klienta którego chcesz edytowac:");

                                try
                                {
                                    int tempID = Convert.ToInt32(Console.ReadLine());
                                    try
                                    {
                                        int tempIDc = Client.client_table[tempID].client_id;

                                        Console.Write("Wpisz numer samochodu ktory ma byc przypisany klientowi:");

                                        try
                                        {
                                            int tempIDcar = Convert.ToInt32(Console.ReadLine());
                                            try
                                            {
                                                int tempIDcarc = Vehicles.table[tempIDcar].id;
                                                Client.client_table[tempIDc].id_samochodu = tempIDcar;
                                                Console.WriteLine("Pomyslnie przepisano samochod!");
                                                Console.WriteLine("enter aby kontynuowac...");
                                                Console.Read();
                                                goto case 0;
                                            }
                                            catch (System.ArgumentOutOfRangeException)
                                            {
                                                Console.WriteLine("Nie ma takiego samochodu");
                                                Console.WriteLine("enter aby kontynuowac...");
                                                Console.Read();
                                                goto case 0;
                                            }
                                        }
                                        catch (System.FormatException)
                                        {
                                            goto case 4;
                                        }
                                    }
                                    catch (System.ArgumentOutOfRangeException)
                                    {
                                        Console.WriteLine("Nie ma takiego klienta");
                                        Console.WriteLine("enter aby kontynuowac...");
                                        Console.Read();
                                        goto case 0;
                                    }

                                }
                                catch (System.FormatException)
                                {
                                    goto case 4;
                                }
                            case 5:
                                Console.Clear();
                                menu_option = 0;
                                break;

                        }
                        break;
                    case 3:

                        int menu_vehicles_option = 0;

                        switch (menu_vehicles_option)
                        {
                            case 0:
                                Console.Clear();
                                Console.WriteLine("Zakładka pojazdy. Co chcesz zrobić?");
                                Console.WriteLine("[1] Wypisz wszystkie pojazdy [2]Zmien Kolor pojazdu [3] Usun pojazd [4]Edytuj silnik pojazdu [5] Usun wlasciciela [6] Dodaj wlasciciela [7] cofnij");
                                
                                try
                                {
                                    menu_vehicles_option = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (System.FormatException)
                                {
                                    Console.Clear();
                                    goto case 0;
                                }


                                if (menu_vehicles_option == 1) goto case 1;
                                if (menu_vehicles_option == 2) goto case 2;
                                if (menu_vehicles_option == 3) goto case 3;
                                if (menu_vehicles_option == 4) goto case 4;
                                if (menu_vehicles_option == 5) goto case 5;
                                if (menu_vehicles_option == 6) goto case 6;
                                if (menu_vehicles_option == 7) goto case 7;
                                
                                break;
                            case 1:
                                Console.Clear();
                                for (int i=0; i < Vehicles.table.Count; i++)
                                {
                                    Console.Write("ID:"+i+"|");
                                    Console.WriteLine(Vehicles.table[i]);
                                }

                                Console.WriteLine("Wypisywanie zakonczone...");
                                Console.WriteLine("enter aby kontynuowac...");
                                Console.Read();
                                goto case 0;

                            case 2:
                                Console.Clear();
                                Console.Write("Podaj id pojazdu ktorego kolor chcesz zmienic:");

                                try
                                {
                                    int temp_id = Convert.ToInt32(Console.ReadLine());
                                    try
                                    {
                                        int temp_id_c = Vehicles.table[temp_id].id;
                                       
                                        Console.Write("Nowy kolor (red,green,blue):");
                                        string temp_col = Console.ReadLine();
                                        
                                        Vehicles.setColour(temp_id, temp_col);
                                        Console.WriteLine("Zmieniono kolor!");
                                        Console.WriteLine("enter aby kontynuowac...");
                                        Console.Read();
                                        goto case 0;
                                    }
                                    catch (System.ArgumentOutOfRangeException)
                                    {
                                        Console.WriteLine("Nie ma takiego pojazdu");
                                        Console.WriteLine("enter aby kontynuowac...");
                                        Console.Read();
                                        goto case 0;
                                    }
                                }
                                catch (System.FormatException)
                                {
                                    goto case 2;
                                }

                            case 3:
                                Console.Clear();
                                Console.Write("Podaj Id pojazdu ktory chcesz usunac:");

                                try
                                {
                                    int temp_id_case3 = Convert.ToInt32(Console.ReadLine());
                                    Vehicles.table.RemoveAt(temp_id_case3);
                                    Console.WriteLine("Usunieto pojazd");
                                    Console.WriteLine("enter aby kontynuowac...");
                                    Console.Read();
                                    goto case 0;
                                }
                                catch (System.ArgumentOutOfRangeException)
                                {
                                    Console.WriteLine("Nie ma takiego pojazdu");
                                    Console.WriteLine("enter aby kontynuowac...");
                                    Console.Read();
                                    goto case 0;
                                }


                            case 4:
                                Console.Clear();
                                Console.Write("Podaj ID pojazdu:");
                                try
                                {
                                    int temp_id_case4 = Convert.ToInt32(Console.ReadLine());
                                    try
                                    {
                                        Console.Write("Podaj nowy stan silnika (old,new):");
                                        string temp_EngineState = Console.ReadLine();
                                        Console.Write("Podaj nowa moc silnika:");
                                        int temp_EnginePower = Convert.ToInt32(Console.ReadLine());
                                        Vehicles.table[temp_id_case4].engine.state = temp_EngineState;
                                        Vehicles.table[temp_id_case4].engine.power = temp_EnginePower;
                                        Console.WriteLine("Pomyslnie edytowano silnik!");
                                        Console.WriteLine("enter aby kontynuowac...");
                                        Console.Read();
                                        goto case 0;
                                    }
                                    catch (System.ArgumentOutOfRangeException)
                                    {
                                        Console.WriteLine("Nie ma pojazdu o takim ID");
                                        Console.WriteLine("enter aby kontynuowac...");
                                        Console.Read();
                                        goto case 0;
                                    }

                                }
                                catch (System.FormatException)
                                {
                                    goto case 4;
                                }
                            case 5:
                                Console.Clear();
                                Console.Write("Podaj id samochodu:");
                                try
                                {
                                    int temp_id_case5 = Convert.ToInt32(Console.ReadLine());
                                    try
                                    {
                                        Vehicles.removeOwner(temp_id_case5);
                                        Console.WriteLine("enter aby kontynuowac...");
                                        Console.Read();
                                        goto case 0;

                                    }
                                    catch (System.ArgumentOutOfRangeException)
                                    {
                                        Console.WriteLine("Nie ma pojazdu o takim ID");
                                        Console.WriteLine("enter aby kontynuowac...");
                                        Console.Read();
                                        goto case 0;
                                    }

                                }
                                catch (System.FormatException)
                                {
                                    goto case 5;
                                }
                            case 6:
                                Console.Clear();
                                Console.Write("Podaj id samochodu:");
                                try
                                {
                                    int temp_id_case6 = Convert.ToInt32(Console.ReadLine());
                                    try
                                    {
                                        Console.Write("Imie:");
                                        string tempfirstname = Console.ReadLine();

                                        if (tempfirstname == "")
                                        {
                                            Console.WriteLine("Nie podano imienia");
                                            Console.WriteLine("enter aby kontynuowac...");
                                            Console.Read();
                                            goto case 0;
                                        }
                                        else
                                        {
                                            Console.Write("Nazwisko:");
                                            string templastname = Console.ReadLine();
                                            Vehicles.addOwner(temp_id_case6, tempfirstname, templastname);
                                            Console.WriteLine("enter aby kontynuowac...");
                                            Console.Read();
                                            goto case 0;

                                        }
                                    }
                                    catch (System.ArgumentOutOfRangeException)
                                    {
                                        Console.WriteLine("Nie ma pojazdu o takim ID");
                                        Console.WriteLine("enter aby kontynuowac...");
                                        Console.Read();
                                        goto case 0;
                                    }
                                }
                                catch (System.FormatException)
                                {
                                    goto case 6;
                                }

                            case 7:
                                menu_option = 0;
                                Console.Clear();
                                break;

                            default:
                                Console.Clear();
                                menu_vehicles_option = 0;
                                Console.WriteLine("Podano zły numer");
                                goto case 0;

                        }

                        break;
                    case 4:

                        int menu_addNew_option = 0;

                        switch (menu_addNew_option)
                        {
                            case 0:
                                Console.Clear();
                                Console.WriteLine("[1] Dodaj nowy samochod [2] Dodaj nowy motor [3] Cofnij");

                                try
                                {
                                    menu_addNew_option = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (System.FormatException)
                                {
                                    goto case 0;
                                }

                                if (menu_addNew_option == 1) goto case 1;
                                if (menu_addNew_option == 2) goto case 1;
                                if (menu_addNew_option == 3)
                                {
                                    Console.Clear();
                                    menu_option = 0;
                                    break;
                                }
                                break;

                            default:
                                Console.Clear();
                                Console.WriteLine("Podano zły numer");
                                menu_addNew_option = 0;
                                goto case 0;

                            case 1:
                            case 2:

                                Console.Clear();
                                Console.WriteLine("Zostaw puste pole jeżeli samochód nie posiada bądź chcesz zostawić domyslna opcje");
                                Console.Write("Podaj marke:");
                                string tempName = Console.ReadLine();
                                Console.Write("Podaj kolor (red,green,blue):");
                                string tempCol = Console.ReadLine();
                                Console.Write("Moc silnika:");

                                string BCtempPow = Console.ReadLine();
                                int tempPow;
                                if (BCtempPow != "") tempPow = Convert.ToInt32(BCtempPow);

                                Console.Write("Podaj status silnika (new,old):");
                                string tempState = Console.ReadLine();
                                Console.Write("Podaj Imie wlasciciela:");
                                string tempOName = Console.ReadLine();
                                string tempOLName = "";
                                if (tempOName == "")
                                {
                                    tempOName = "Brak wlasciciela";
                                }
                                else
                                {
                                    Console.Write("Podaj nazwisko wlaciciela:");
                                    tempOLName = Console.ReadLine();
                                }

                                if (menu_addNew_option == 1) NewCar.add(tempName, tempCol, tempPow = 200, tempState, tempOName, tempOLName);
                                else
                                NewMotor.add(tempName, tempCol, tempPow = 150, tempState, tempOName, tempOLName);

                                menu_addNew_option = 0;
                                Console.WriteLine("enter aby kontynuowac...");
                                Console.Read();
                                goto case 0;
                        }
                        break;
                    default:
                        Console.WriteLine("Podano zły numer");
                        menu_option = 0;
                        break;

                }
            }
            

        }

    }
}
