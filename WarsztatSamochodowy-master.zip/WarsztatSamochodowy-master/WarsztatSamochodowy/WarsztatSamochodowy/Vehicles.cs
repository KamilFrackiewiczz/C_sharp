﻿using System;
using System.Buffers;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace WarsztatSamochodowy
{
    class Vehicles
    {
        //Override ToStringa Dla Klasy Vehicles
        public override string ToString()
        {
            return  "Kolor:"+colour + " Marka:" + name + " | Rodzaj:" + type + " | Wlasciciel: " + owner.firstname + " " + owner.lastname + " | Silnik:" + engine.state + " " + engine.power+"HP";
        }
        //Inicjalizacja zmiennych + wlasciwosci
        public string name { get; private set; }
        public string colour { get; private set; }
        protected double price { get; set; }
        public string type { get; private set; }
        public int id { get; private set;}
        public Engine engine;
        private Human owner;
        public static int nextId = 0;
        
        
        //Tabela ze wszystkimi obiektami Vehicles
        
        public static Collection<Vehicles> table = new Collection<Vehicles>();

        //Obiekt Silnika/kontruktor/funkcje

        public class Engine
        {
            public int power;
            public string state;
            public Engine(int power=500, string state="new")
            {
                this.power = power;
                this.state = state;
            }
            //Komenda która zwraca dane o silniku dla obiektu typu Vehicles
            public void getEngineValues()
            {
                string statePL;

                if (state == "new")
                    statePL = "nowy";
                else if (state == "used")
                    statePL = "używany";
                else
                    statePL = "zniszczony";

                Console.WriteLine("Silnik jest " + statePL + " a jego moc wynosi " + power + " koni"); 
            }
            //Funkcja zwracająca Moc silnika (power)
            public int getPower()
            {
                return this.power;
            }
            private string getState()
            {
                return this.state;
            }
            
        }

        //KONSTRUKTOR obiektu Vehicles

        public Vehicles(string name, string colour, int EnginePower, string EngineState, string OwnerName,string OwnerLastName, string type = "car")
        {
            owner = new Client (OwnerName, OwnerLastName);
            engine = new Engine(EnginePower, EngineState);
            this.id = nextId;
            nextId++;
            this.name = name;
            this.colour = colour;
            this.type = type;
            //Ustalanie ceny dla pojazu w zaleznosci czy jest to motor/samochdow
            if (type == "car")
            {
                if (colour == "red")
                {
                    this.price = Quantity.getPriceRed();
                    Quantity.redQnt++;
                }
                else if (colour == "blue")
                {
                    this.price = Quantity.getPriceBlue();
                    Quantity.blQnt++;
                }
                else if (colour == "green")
                {
                    this.price = Quantity.getPriceGreen();
                    Quantity.grnQnt++;
                }
                else
                {
                    this.price = 0;
                    Quantity.unkQnt++;
                }

            } else
                    if (colour == "red")
                {
                this.price = Quantity.getPriceRed() / 2;
                Quantity.redQnt++;
                }
                else if (colour == "blue")
                {
                    this.price = Quantity.getPriceBlue()/2;
                Quantity.blQnt++;
                }
                else if (colour == "green")
                {
                    this.price = Quantity.getPriceGreen()/2;
                Quantity.grnQnt++;
                }
                else
                {
                    this.price = 0;
                    Quantity.unkQnt++;
                }
               
       

    }
        //Metoda zmieniająca marke samochodu ID
        public static void setNameById(int id,string name)
        {
            Vehicles.table[id].name=name;
        }
        //Metoda dodajaca klienta do samochodu o danym ID i dodajaca go do bazy wszystkich klientów (Human.tables)
        public static void addOwner(int id, string firstname, string lastname)
        {
            if (Vehicles.table[id].owner.firstname == "unk")
            {
                Client.client_table[id].AddToTable(firstname, lastname);
                Vehicles.table[id].owner.firstname = firstname;
                Vehicles.table[id].owner.lastname = lastname;
                Console.WriteLine("Przypisano wlasciciela "+firstname+" "+lastname+" do pojazdu o id "+id);

            }
            else Console.WriteLine("Ten pojazd posiada już właściela, jeżeli chcesz go nadpisać - usuń dotychczasowego");
        }
        //Metoda usuwajaca kleinta z samochodu o podanym ID
        public static void removeOwner(int id)
        {
            if (Vehicles.table[id].owner.firstname != "unk")
            {
                Vehicles.table[id].owner.firstname = "unk";
                Vehicles.table[id].owner.lastname = "unk";
                Console.WriteLine("Usunieto wlasciciela samochodu o id " + id);

            }
            else Console.WriteLine("Ten samochod nie posiada już wlasciciela");
        }
        //Metoda zmieniajaca kolor/cene pojazdu o podanym ID
        public static void setColour(int id,string colour)
        {

            if (Vehicles.table[id].colour == "red")
                Quantity.redQnt--;
            else if (Vehicles.table[id].colour == "blue")
                Quantity.blQnt--;
            else if (Vehicles.table[id].colour == "green")
                Quantity.grnQnt--;
            else Quantity.unkQnt--;

            if (colour == "red")
            {
                if (Vehicles.table[id].type == "car")

                    Vehicles.table[id].price = Quantity.getPriceRed(); 
                else
                    Vehicles.table[id].price = Quantity.getPriceRed()/2; 

                Quantity.redQnt++;
            }
            else if (colour == "blue")
            {
                if (Vehicles.table[id].type == "car")

                    Vehicles.table[id].price = Quantity.getPriceBlue(); 
                else
                    Vehicles.table[id].price = Quantity.getPriceBlue()/2;

                Quantity.blQnt++;
            }
            else if ( colour == "green")
            {
                if (Vehicles.table[id].type == "car")

                    Vehicles.table[id].price = Quantity.getPriceGreen();
                else
                    Vehicles.table[id].price = Quantity.getPriceGreen()/2;

                Quantity.grnQnt++;
            }
            else
            {

                Vehicles.table[id].price = 0;

                Quantity.unkQnt++;

            }
            Vehicles.table[id].colour = colour;
            Console.WriteLine("You've changed the colour of the following ID car to " + colour);
        }
        //Metoda zwracajaca klienta samochodu o danym ID
        public static string getOwner(int id)
        {
            return Vehicles.table[id].owner.firstname + " " + Vehicles.table[id].owner.lastname;
        }

        //Funkcje zwracajaca informacje o silniku
        public static void getEngineById(int i)
        {
            Vehicles.table[i].engine.getEngineValues();
        }
        public static string getEngineStateById(int i)
        {
            return Vehicles.table[i].engine.state;
        }
        public static int getEnginePowerById(int i)
        {
            return Vehicles.table[i].engine.power;
        }

        //Funkcja zwracająca informacje o pojezdzie o danym ID
        public static void getInfVeh(int i)
        {
            Console.WriteLine("It is " + Vehicles.table[i].colour + " " + Vehicles.table[i].type + " with " + Vehicles.table[i].engine.getPower() + " horse power and it costs " + Vehicles.table[i].price + " zl"); ;
        }


        
    }


}
