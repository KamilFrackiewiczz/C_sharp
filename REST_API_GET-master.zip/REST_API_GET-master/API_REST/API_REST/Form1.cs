﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace API_REST
{
    public partial class Form1 : Form
    {
        //[{"id":2,"name":"Homer Simpson","email":"homer@email.com","nationality":"United States of America"},{"id":3,"name":"Adam Smith","email":"adam@email.com","nationality":"Scottish"},{"id":4,"name":"Lemmy","email":"lemmy@email.com","nationality":"British"},{"id":5,"name":"Dame Edna Everage","email":"dameedna@email.com","nationality":"Australian"}]
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            restApiClient Client = new restApiClient();
            Client.endPoint = urlText.Text;

            debugOutput("Sucesfully Created...");

            string strResponse = string.Empty;

            strResponse = Client.makeRequest();

            debugOutput(strResponse);


        }

        private void urlText_TextChanged(object sender, EventArgs e)
        {

        }
        private void debugOutput(string strDebutText)
        {
            System.Diagnostics.Debug.WriteLine(strDebutText + Environment.NewLine);
            txtResponse.Text = txtResponse.Text + strDebutText + Environment.NewLine;
            txtResponse.SelectionStart = txtResponse.TextLength;
            txtResponse.ScrollToCaret();
    }
    }
}
